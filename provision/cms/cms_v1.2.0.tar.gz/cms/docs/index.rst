Welcome to CMS's documentation!
===============================

.. toctree::
   :maxdepth: 2

   Introduction
   Installation
   Running CMS
   Creating a contest
   Configuring a contest
   Detailed timing configuration
   Task types
   Score types
   Task versioning
   External contest formats
   RankingWebServer
   Localization
   Troubleshooting
   Internals
