public class batchfileiomanaged {

    public static int userfunc(int x) {
        return x + 1;
    }

}
