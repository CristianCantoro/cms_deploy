<?php
$n = intval(fgets(STDIN));
echo "correct $n\n";
?>
