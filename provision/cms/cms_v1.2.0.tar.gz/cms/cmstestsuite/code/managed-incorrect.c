int userfunc(int x) {
    return x + 1;
}
