#!/bin/bash

# Remember to execute as root :-)

chown root isolate
chmod u+s isolate

