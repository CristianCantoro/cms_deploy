#include <stdio.h>

int main() {
    int n;
    scanf("%d", &n);
    printf("correct %d\n", n);
    return 1;
}
