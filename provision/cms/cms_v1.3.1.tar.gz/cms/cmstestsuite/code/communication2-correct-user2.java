public class user2 {

    public static int userfunc2(int x) {
        return -x;
    }

}
