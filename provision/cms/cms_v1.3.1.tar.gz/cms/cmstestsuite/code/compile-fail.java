
public class batchfileio {

    public static void main(String[] args) {
        Mmh no, it will not work
    }
}
