#include <stdio.h>

int main() {
    int n;
    scanf("%d", &n);
    printf("incorrect %d\n", n);
    return 0;
}
