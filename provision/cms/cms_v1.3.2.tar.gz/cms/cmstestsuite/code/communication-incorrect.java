public class communication {

    public static int userfunc(int x) {
        return x + 1;
    }

}
